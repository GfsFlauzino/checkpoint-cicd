<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Aqui você pode adicionar a lógica de autenticação, como verificar no banco de dados.
    // Por simplicidade, estamos apenas verificando se o username e senha são "admin".

    if ($username === "admin" && $password === "admin") {
        // Autenticação bem-sucedida, redirecione para a página de sucesso ou gere um log.
        header("Location: success.html");
        exit();
    } else {
        echo "Credenciais inválidas. Tente novamente.";
    }
}
?>
